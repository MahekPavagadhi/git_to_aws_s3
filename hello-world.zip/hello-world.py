def index(event,context):
	print ('Lambda Code is updated!')
