def lambda_handler(event,context):
	print ('Hello from git')
	print ('Hello from git again')
